package chess;
import chess.*;

public enum Color {
    WHITE, BLACK
}
